

<?php 
require('header.php');
?>
       

					   <form action="insert.php" method="post" enctype="multipart/form-data">
					  <div class="form-group">
					    <label for="exampleInputEmail1">account:</label>
					    <input type="text" name="account" class="form-control"   placeholder="account " >
					    
					  </div>
					  <div class="form-group">
					    <label for="exampleInputPassword1">Parent_id:</label>
					    <input type="text" name="parent_id" class="form-control" id="exampleInputPassword1" placeholder="parent_id" >
					  </div>				  
					  
					  <button type="submit" class="btn btn-primary">Submit</button>
					  <a  class="btn btn-primary"href="showdata.php">Showdata</a>
					  					</form>




    		
    		

 <?php 
require('footer.php');
?>

		






	
	

