

<?php
require('connect.php');
$trn_mst_id=$_POST['trn_mst_id'];
$trn_typ_id= $_POST['trn_typ_id'];
$trn_cat_id= $_POST['trn_cat_id'];

 $sql="UPDATE  trn_mst SET trn_typ_id='$trn_typ_id',trn_cat_id='$trn_cat_id' WHERE trn_mst_id='$trn_mst_id'";


mysqli_query($connect,$sql);

header('location:showdata_trn_mst.php?message=Data Updated Successfully');

?>


