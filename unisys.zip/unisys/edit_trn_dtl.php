

<?php 
require('header.php');
?>

<?php 
 require('connect.php');
 $trn_dtl_id =$_GET['trn_dtl_id'];
 $sql="SELECT * FROM trn_dtl where trn_dtl_id='$trn_dtl_id'";
 $query=mysqli_query($connect,$sql);
 $data=mysqli_fetch_assoc($query);
 ?>
  			<form action="update_trn_dtl.php" method="post" enctype="multipart/form-data">
  			<input class="form-control" type="hidden" name="trn_dtl_id" value="<?php echo $trn_dtl_id; ?>">
			trn_mst_id:<input class="form-control" type="text" name="trn_mst_id" value="<?php echo $data['trn_mst_id'] ?>"><br> 
			acc_id:<input class="form-control" type="text" name="acc_id" value="<?php echo $data['acc_id'] ?>" ><br>
			acc_status:<input class="form-control" type="text" name="acc_status" value="<?php echo $data['acc_status'] ?>" ><br>
			amount:<input class="form-control" type="text" name="amount" value="<?php echo $data['amount'] ?>" ><br>
			
			<input class="btn btn-primary" type="submit" value="Update">
			</form>

		
<?php 
require('footer.php');
?>
