

<?php
//session_start();
require('connect.php');

$trn_mst_id=$_POST['trn_mst_id'];
$acc_id=$_POST['acc_id'];
$acc_status=$_POST['acc_status'];
$amount=$_POST['amount'];



$sql="INSERT INTO  trn_dtl (trn_mst_id,acc_id,acc_status,amount) VALUES ('$trn_mst_id','$acc_id','$acc_status','$amount')";


mysqli_query($connect,$sql);
header("location:showdata_trn_dtl.php?message=Data Inserted Successfully.");



?>



