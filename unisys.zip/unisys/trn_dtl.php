

<?php 
require('header.php');
?>      

					   <form action="insert_trn_dtl.php" method="POST" enctype="multipart/form-data">
					  <div class="form-group">
					    <label for="exampleInputEmail1">trn_mst_id:</label>
					    <input type="text" name="trn_mst_id" class="form-control"   placeholder="trn_mst_id" >					    
					  </div>
					  <div class="form-group">
					    <label for="exampleInputPassword1">Acc_id:</label>
					    <input type="text" name="acc_id" class="form-control" id="exampleInputPassword1" placeholder="acc_id" >
					  </div>				  
					  <div class="form-group">
					    <label for="exampleInputPassword1">acc_status:</label>
					    <input type="text" name="acc_status" class="form-control" id="exampleInputPassword1" placeholder="acc_status" >
					  </div>
					  <div class="form-group">
					    <label for="exampleInputPassword1">Amount:</label>
					    <input type="text" name="amount" class="form-control" id="exampleInputPassword1" placeholder="amount" >
					  </div>
					  <button type="submit" class="btn btn-primary">Submit</button>
					  <a  class="btn btn-primary"href="showdata_trn_dtl.php">Showdata</a>
					</form>   		
    		

 <?php 
require('footer.php');
?>

		






	
	

