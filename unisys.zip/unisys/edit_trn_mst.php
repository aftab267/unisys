

<?php 
require('header.php');
?>

<?php 
 require('connect.php');
 $trn_mst_id=$_GET['trn_mst_id'];
 $sql="SELECT * FROM trn_mst where trn_mst_id='$trn_mst_id'";
 $query=mysqli_query($connect,$sql);
 $data=mysqli_fetch_assoc($query);
 ?>
  				<form action="update_trn_mst.php" method="post" enctype="multipart/form-data">
  				<input class="form-control" type="hidden" name="trn_mst_id" value="<?php echo $trn_mst_id; ?>">
			trn_typ_id:<input class="form-control" type="text" name="trn_typ_id" value="<?php echo $data['trn_typ_id'] ?>"><br> 
			trn_cat_id:<input class="form-control" type="text" name="trn_cat_id" value="<?php echo $data['trn_cat_id'] ?>" ><br>
			
			<input class="btn btn-primary" type="submit" value="Update">
			</form>

		
<?php 
require('footer.php');
?>
