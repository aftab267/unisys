<?php
require('connect.php');
$trn_dtl_id=$_GET['trn_dtl_id'];
$sql="delete from trn_dtl where trn_dtl_id='$trn_dtl_id'";
mysqli_query($connect,$sql);
header('location:showdata_trn_dtl.php?message=Data Deleted Successfully');



?>