

<?php
//session_start();
require('connect.php');

$trn_typ_id= $_POST['trn_typ_id'];
$trn_cat_id= $_POST['trn_cat_id'];

$sql="INSERT INTO trn_mst (trn_typ_id,trn_cat_id) VALUES ('$trn_typ_id','$trn_cat_id')";

mysqli_query($connect,$sql);
header("location:showdata_trn_mst.php?message=Data Inserted Successfully.");



?>



