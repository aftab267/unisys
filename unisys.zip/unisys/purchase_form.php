<?php 
require('header.php');
?>
    <form action="purchase_insert.php" method="post" enctype="multipart/form-data">
    <div class="container">
        <div class="card">
            <div class="card-header">
                
                <strong>Invoice/Challan Add Form</strong>
                

            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-sm-4">
                        <h6 class="mb-3">From:</h6>
                        <div>
                    <!-- <strong>invoice number  :  <input class="form-control" type="text" name="invoice_number" placeholder="Invoice Number"></strong> -->
                        </div><br>
                    <div class="form-control">Customer : <select name="customer" >
                            <option>Select Customer</option>
                            <option>Kazi Aftabur</option>
                            <option>Noor Shakil</option>
                        </select>  </div><br>
                        <div class="form-control"> Invoice Date: <input class="form-control" type="date" name="invoice_date" placeholder="invoice_date"></div><br>
                        <div class="form-control"> Due Date: <input class="form-control" type="date" name="due_date" placeholder="Due Date"></div><br>

                        
                        <div>Barcode: <input type="text" name="barcode" placeholder="Barcode"></div>
                        
                    </div>

                    
                </div>

                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                
                                <th width='400'>Product Name: <br><select name="product_name" >
                                    <option>Product Name</option>
                                </select></th>
                                <th>Unit: <br> <input type="text" name="unit" placeholder="unit"></th>
                                <th>Quantity: <br> <input type="text" name="quantity" placeholder="quantity"></th>
                                <th>Price: <br> <input type="text" name="price" placeholder="Price"></th>
                                <th>Add: <input type="submit" name="submit" value="+Add" ></th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                
                                <th>Product Count: <br> <input type="text" name="product_count" placeholder="0"></th>
                                <td class="left"></td>

                                <th>Sub Total: <br> <input type="text" name="sub_total" placeholder="0"></th>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"><div>Discount Type:<br><select name="discount_type">
                            <option>Fixed</option>
                            <option>Percentage</option>
                        </select>  </div><br></td>
                                <td class="left"></td>
                                <td class="left">Discount: <br> <input type="text" name="discount" placeholder="0"></td>

                                <td></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"></td>
                                <td class="left"><td class="left">Miscellaneous: <br> <input type="text" name="miscellaneous" placeholder="0"></td></td>
                                <td class="left"></td>

                                <td class="right"></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"></td>
                                <td class="left"><td class="left">Total: <br> <input type="text" name="total" placeholder="0"></td></td>
                                <td class="left"></td>

                                <td class="right"></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"></td>
                                <td class="left"><td class="left"> <br> <input class="btn btn-primary" type="submit" name="submit" ></a></td></td>
                                
                                <td class="left"><a href="showdata_purchase.php" type="submit" value="show">show</a></td>

                                <td class="right"></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-5">

                    </div>

                   
                </div>
            </div>
        </div>
    </div>
    </form>
<?php 
require('footer.php');
?>
