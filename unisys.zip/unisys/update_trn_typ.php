

<?php
require('connect.php');
$trn_typ_id=$_POST['trn_typ_id'];
$trn_typ_name= $_POST['trn_typ_name'];
$trn_typ_prn= $_POST['trn_typ_prn'];

 $sql="UPDATE  trn_typ SET trn_typ_name='$trn_typ_name',trn_typ_prn='$trn_typ_prn' WHERE trn_typ_id='$trn_typ_id'";


mysqli_query($connect,$sql);

header('location:showdata_trn_typ.php?message=Data Updated Successfully');

?>


