<?php
require('connect.php');
$trn_mst_id=$_GET['trn_mst_id'];
$sql="delete from trn_mst where trn_mst_id='$trn_mst_id'";
mysqli_query($connect,$sql);
header('location:showdata_trn_mst.php?message=Data Deleted Successfully');



?>