<?php 
require('header.php');
?>
<?php 
 require('connect.php');
 $invoice_number=$_GET['invoice_number'];
 $sql="SELECT * FROM purchase_form WHERE invoice_number='$invoice_number'";
 $query=mysqli_query($connect,$sql);
 $data=mysqli_fetch_assoc($query);
 ?>
  				<form action="update_purchase.php" method="POST" enctype="multipart/form-data">    
                
                <strong>Invoice/Challan Add Form</strong>               

                
                        <h6 class="mb-3">From:</h6>
                        
                    <input class="form-control" type="hidden" name="invoice_number" value="<?php echo $invoice_number; ?>">
                        <br>

                        Customer : <select name="customer" class="form-control">
                            <option>Select Customer</option>
                            <option>Kazi Aftabur</option>
                            <option>Noor Shakil</option>
                        </select>  </div><br>

                Invoice Date: <input class="form-control" type="date" name="invoice_date" value="<?php echo $data['invoice_date'] ?>" placeholder="invoice_date"></div><br>

                Due Date: <input class="form-control" type="date" name="due_date" value="<?php echo $data['due_date'] ?>" placeholder="Due Date"><br>

                        
                      Barcode: <input type="text" name="barcode" value="<?php echo $data['barcode'] ?>" placeholder="Barcode"></div>                        
                    
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                
                                <th width='400'>Product Name: <br><select name="product_name" >
                                    <option>Product Name</option>
                                </select></th>

                                <th>Unit: <br> <input type="text" value="<?php echo $data['unit'] ?>" name="unit" placeholder="unit"></th>

                                <th>Quantity: <br> <input type="text" value="<?php echo $data['quantity'] ?>" name="quantity" placeholder="quantity"></th>

                                <th>Price: <br> <input type="text" value="<?php echo $data['price'] ?>" name="price" placeholder="Price"></th>

                                <th>Add: <input type="submit" name="submit" value="+Add" ></th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                
                                <th>Product Count: <br> <input type="text" value="<?php echo $data['product_count'] ?>" name="product_count" placeholder="0"></th>

                                <td class="left"></td>

                                <th>Sub Total: <br> <input type="text" value="<?php echo $data['sub_total'] ?>" name="sub_total" placeholder="0"></th>

                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"><div>Discount Type:<br><select name="discount_type">
                            <option>Fixed</option>
                            <option>Percentage</option>
                        </select>  </div><br></td>
                                <td class="left"></td>
                                <td class="left">Discount: <br> <input type="text" value="<?php echo $data['discount'] ?>" name="discount" placeholder="0"></td>

                                <td></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"></td>
                                <td class="left"><td class="left">Miscellaneous: <br> <input type="text" value="<?php echo $data['miscellaneous'] ?>" name="miscellaneous" placeholder="0"></td></td>

                                <td class="left"></td>

                                <td class="right"></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"></td>
                                <td class="left"><td class="left">Total: <br> <input type="text" name="total" value="<?php echo $data['total'] ?>" placeholder="0"></td></td>
                                <td class="left"></td>

                                <td class="right"></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                            <tr>
                                <td class="center"></td>
                                <td class="left"><td class="left"> <br> <input class="btn btn-primary" type="submit" name="submit" value="Update" ></td></td>
                                
                                <td class="left"></td>

                                <td class="right"></td>
                                <td class="center"></td>
                                <td class="right"></td>
                            </tr>
                        </tbody>
                    </table>
                
    </form>

		
<?php 
require('footer.php');
?>
