

<?php
//session_start();
require('connect.php');

$account= $_POST['account'];
$parent_id=$_POST['parent_id'];


$sql="INSERT INTO coa (account,parent_id) VALUES ('$account','$parent_id')";	


mysqli_query($connect,$sql);
header("location:showdata.php?message=Data Inserted Successfully.");



?>



