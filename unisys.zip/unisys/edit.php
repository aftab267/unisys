

<?php 
require('header.php');
?>
<?php 
 require('connect.php');
 $coa_id=$_GET['coa_id'];
 $sql="SELECT * FROM coa where coa_id='$coa_id'";
 $query=mysqli_query($connect,$sql);
 $data=mysqli_fetch_assoc($query);
 ?>
  				<form action="update.php" method="post" enctype="multipart/form-data">
  				<input class="form-control" type="hidden" name="coa_id" value="<?php echo $coa_id; ?>">
			Account:<input class="form-control" type="text" name="account" value="<?php echo $data['account'] ?>"><br> 
			Parent Id:<input class="form-control" type="text" name="parent_id" value="<?php echo $data['parent_id'] ?>" ><br>
			
			<input class="btn btn-primary" type="submit" value="Update">
			</form>

		
<?php 
require('footer.php');
?>
