<?php
require('connect.php');


$customer=$_POST['customer'];
$invoice_date=$_POST['invoice_date'];
$due_date=$_POST['due_date'];
$barcode=$_POST['barcode'];
$product_name=$_POST['product_name'];
$unit=$_POST['unit'];
$quantity=$_POST['quantity'];
$price=$_POST['price'];
$product_count=$_POST['product_count'];
$sub_total=$_POST['sub_total'];
$discount_type=$_POST['discount_type'];
$discount=$_POST['discount'];
$miscellaneous=$_POST['miscellaneous'];
$total=$_POST['total'];


	$sub_total=$quantity*$price;
	$total=$sub_total-$discount+$miscellaneous;





$sql="INSERT INTO  purchase_form (customer,invoice_date,due_date,barcode,product_name,unit,quantity,price,product_count,sub_total,discount_type,discount,miscellaneous,total)  VALUES  ('$customer','$invoice_date','$due_date','$barcode','$product_name','$unit','$quantity','$price','$product_count','$sub_total','$discount_type','$discount','$miscellaneous','$total')";


mysqli_query($connect,$sql);
header("location:showdata_purchase.php?message=Data Inserted Successfully.");

?>