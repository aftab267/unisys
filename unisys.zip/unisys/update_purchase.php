

<?php
require('connect.php');
$invoice_number=$_POST['invoice_number'];
$customer=$_POST['customer'];
$invoice_date= $_POST['invoice_date'];
$due_date= $_POST['due_date'];
$barcode= $_POST['barcode'];
$unit= $_POST['unit'];
$quantity= $_POST['quantity'];
$price= $_POST['price'];
$product_count= $_POST['product_count'];
$sub_total= $_POST['sub_total'];
$discount_type= $_POST['discount_type'];
$discount= $_POST['discount'];
$miscellaneous= $_POST['miscellaneous'];
$product_name= $_POST['product_name'];
$total= $_POST['total'];

    $sub_total=$quantity*$price;
    $total=$sub_total-$discount+$miscellaneous;

 $sql="UPDATE  purchase_form SET customer='$customer',invoice_date='$invoice_date',due_date='$due_date',barcode='$barcode',unit='$unit',quantity='$quantity',price='$price',product_count='$product_count',sub_total='$sub_total',discount_type='$discount_type',discount='$discount',miscellaneous='$miscellaneous',product_name='$product_name',total='$total' WHERE invoice_number ='$invoice_number'";


mysqli_query($connect,$sql);

header('location:showdata_purchase.php?message=Data Updated Successfully');

?>


