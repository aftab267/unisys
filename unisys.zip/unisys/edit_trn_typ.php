

<?php 
require('header.php');
?>

<?php 
 require('connect.php');
 $trn_typ_id =$_GET['trn_typ_id'];
 $sql="SELECT * FROM trn_typ where trn_typ_id='$trn_typ_id'";
 $query=mysqli_query($connect,$sql);
 $data=mysqli_fetch_assoc($query);
 ?>
  				<form action="update_trn_typ.php" method="post" enctype="multipart/form-data">
  				<input class="form-control" type="hidden" name="trn_typ_id" value="<?php echo $trn_typ_id; ?>">
			trn_typ_name:<input class="form-control" type="text" name="trn_typ_name" value="<?php echo $data['trn_typ_name'] ?>"><br> 
			trn_typ_prn:<input class="form-control" type="text" name="trn_typ_prn" value="<?php echo $data['trn_typ_prn'] ?>" ><br>
			
			<input class="btn btn-primary" type="submit" value="Update">
			</form>

		
<?php 
require('footer.php');
?>
