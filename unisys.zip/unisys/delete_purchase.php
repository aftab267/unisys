<?php
require('connect.php');
$invoice_number=$_GET['invoice_number'];
$sql="delete from purchase_form where invoice_number='$invoice_number'";
mysqli_query($connect,$sql);
header('location:showdata_purchase.php?message=Data Deleted Successfully');



?>