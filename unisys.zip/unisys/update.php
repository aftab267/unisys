

<?php
require('connect.php');
$coa_id=$_POST['coa_id'];
$account= $_POST['account'];
$parent_id= $_POST['parent_id'];

 $sql="UPDATE coa SET account='$account',parent_id='$parent_id' WHERE coa_id='$coa_id'";


mysqli_query($connect,$sql);

header('location:showdata.php?message=Data Updated Successfully');

?>


