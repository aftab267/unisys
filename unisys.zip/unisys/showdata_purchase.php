
<?php 
require('header.php');
?>    

<?php
//code start
require('connect.php');
$sql="SELECT * FROM purchase_form";
$query=mysqli_query($connect,$sql);
?>
<?php if(isset($_GET['message'])){  ?>
<p><?php echo $_GET['message'] ?></p>
<?php } ?>
<a href="logout.php"class="btn btn-primary">Log Out</a>
<a href="purchase_form.php"class="btn btn-primary">Insert</a>
<table class="table table-bordered table-hover">
  <tr>
    <td><b>SL</b></td>
    <td><b>Customer<b></td>
    <td><b>Invoice date<b></td>
    <td><b>Due date<b></td>
    <td><b>Barcode<b></td>
    <td><b>product_name<b></td>
    <td><b>unit<b></td>
    <td><b>quantity<b></td>
    <td><b>price<b></td>
    <td><b>product_count<b></td>
    <td><b>sub_total<b></td>
    <td><b>discount_type<b></td>
    <td><b>discount<b></td>
    <td><b>miscellaneous<b></td>
    <td><b>total<b></td>

    <td><b>Action<b></td>
  </tr>
  <?php
  $x=1;
  foreach($query as $val){

  ?>
  <tr>
    <td><?php echo $x++ ?></td>
    <td><?php echo $val['customer'] ?></td>
    <td><?php echo $val['invoice_date'] ?></td>
    <td><?php echo $val['due_date'] ?></td>
    <td><?php echo $val['barcode'] ?></td>
    <td><?php echo $val['product_name'] ?></td>
    <td><?php echo $val['unit'] ?></td>
    <td><?php echo $val['quantity'] ?></td>
    <td><?php echo $val['price'] ?></td>
    <td><?php echo $val['product_count'] ?></td>
    <td><?php echo $val['sub_total'] ?></td>
    <td><?php echo $val['discount_type'] ?></td>
    <td><?php echo $val['discount'] ?></td>
    <td><?php echo $val['miscellaneous'] ?></td>
    <td><?php echo $val['total'] ?></td>
    
    <td>
     <a href="edit_purchase.php?invoice_number=<?php echo $val['invoice_number'] ?>"><button class="btn btn-primary">Edit</button></a>
  <a href="delete_purchase.php?invoice_number=<?php echo $val['invoice_number'] ?>" onclick="return confirm('Are you sure to delete?')"><button class="btn btn-danger">Delete</button></a></td>
  </tr>
  <?php
  }
  ?>
  
</table>
  </div>
</body>
</html>



<?php 
require('footer.php');
?>



