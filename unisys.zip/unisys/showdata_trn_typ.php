
<?php 
require('header.php');
?>    

<?php
//code start
require('connect.php');
$sql="SELECT * FROM trn_typ";
$query=mysqli_query($connect,$sql);
?>
<?php if(isset($_GET['message'])){  ?>
<p><?php echo $_GET['message'] ?></p>
<?php } ?>
<a href="logout.php"class="btn btn-primary">Log Out</a>
<a href="trn_typ.php"class="btn btn-primary">Insert</a>
<table class="table table-bordered table-hover">
  <tr>
    <td><b>SL</b></td>
    <td><b>trn_typ_name<b></td>
    <td><b>trn_typ_prn<b></td>
    <td><b>Action<b></td>
  </tr>
  <?php
  $x=1;
  foreach($query as $val){

  ?>
  <tr>
    <td><?php echo $x++ ?></td>
    <td><?php echo $val['trn_typ_name'] ?></td>
    <td><?php echo $val['trn_typ_prn'] ?></td>
    
    <td>
     <a href="edit_trn_typ.php?trn_typ_id=<?php echo $val['trn_typ_id'] ?>"><button class="btn btn-primary">Edit</button></a>
      <a href="delete_trn_typ.php?trn_typ_id=<?php echo $val['trn_typ_id'] ?>" onclick="return confirm('Are you sure to delete?')"><button class="btn btn-danger">Delete</button></a></td>
  </tr>
  <?php
  }
  ?>
</table>
  </div>
</body>
</html>



<?php 
require('footer.php');
?>



