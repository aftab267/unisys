<?php
require('connect.php');
$trn_typ_id=$_GET['trn_typ_id'];
$sql="delete from trn_typ where trn_typ_id='$trn_typ_id'";
mysqli_query($connect,$sql);
header('location:showdata_trn_typ.php?message=Data Deleted Successfully');
?>