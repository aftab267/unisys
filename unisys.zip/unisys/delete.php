<?php
require('connect.php');
$coa_id=$_GET['coa_id'];
$sql="delete from coa where coa_id='$coa_id'";
mysqli_query($connect,$sql);
header('location:showdata.php?message=Data Deleted Successfully');



?>