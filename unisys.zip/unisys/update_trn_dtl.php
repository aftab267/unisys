

<?php
require('connect.php');
$trn_dtl_id=$_POST['trn_dtl_id'];
$trn_mst_id=$_POST['trn_mst_id'];
$acc_id= $_POST['acc_id'];
$acc_status= $_POST['acc_status'];
$amount= $_POST['amount'];

 $sql="UPDATE  trn_dtl SET trn_mst_id='$trn_mst_id',acc_id='$acc_id',acc_status='$acc_status',amount='$amount' WHERE trn_dtl_id ='$trn_dtl_id '";


mysqli_query($connect,$sql);

header('location:showdata_trn_dtl.php?message=Data Updated Successfully');

?>


