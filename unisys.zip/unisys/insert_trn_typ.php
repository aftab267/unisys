

<?php
//session_start();
require('connect.php');

$trn_typ_name= $_POST['trn_typ_name'];
$trn_typ_prn= $_POST['trn_typ_prn'];


$sql="INSERT INTO trn_typ (trn_typ_name,trn_typ_prn) VALUES ('$trn_typ_name','$trn_typ_prn')";	


mysqli_query($connect,$sql);
header("location:showdata_trn_typ.php?message=Data Inserted Successfully.");

mysqli_query($connect,$sql);

?>



