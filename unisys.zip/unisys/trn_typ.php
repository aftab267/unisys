

<?php 
require('header.php');
?>
       

					   <form action="insert_trn_typ.php" method="post" enctype="multipart/form-data">
					  <div class="form-group">
					    <label for="exampleInputEmail1">trn_typ_name:</label>
					    <input type="text" name="trn_typ_name" class="form-control"   placeholder="trn_typ_name " >					    
					  </div>
					  <div class="form-group">
					    <label for="exampleInputPassword1">trn_typ_prn:</label>
					    <input type="text" name="trn_typ_prn" class="form-control" id="exampleInputPassword1" placeholder="trn_typ_prn" >
					  </div>				  
					  <button type="submit" class="btn btn-primary">Submit</button>
					  <a  class="btn btn-primary"href="showdata_trn_typ.php">Showdata</a>
					</form>




    		
    		

 <?php 
require('footer.php');
?>

		






	
	

